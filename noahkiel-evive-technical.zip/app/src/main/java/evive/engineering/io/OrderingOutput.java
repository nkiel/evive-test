package evive.engineering.io;

// potentially could extend BufferedInputStream or similar class
public interface OrderingOutput {
    public void printOrder(String order);
}
